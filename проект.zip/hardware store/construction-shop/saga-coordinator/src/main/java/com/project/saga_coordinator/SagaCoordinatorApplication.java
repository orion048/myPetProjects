package com.project.saga_coordinator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SagaCoordinatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SagaCoordinatorApplication.class, args);
	}

}
